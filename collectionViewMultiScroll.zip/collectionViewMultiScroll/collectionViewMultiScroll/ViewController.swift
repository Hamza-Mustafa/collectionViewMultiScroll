//
//  ViewController.swift
//  collectionViewMultiScroll
//
//  Created by Hamza Mustafa on 13/10/2020.
//

import UIKit

class ViewController: UIViewController {
    
    let imgArray = [ #imageLiteral(resourceName: "banner") , #imageLiteral(resourceName: "banner2") ,#imageLiteral(resourceName: "banner") ,#imageLiteral(resourceName: "banner2") ,#imageLiteral(resourceName: "banner") ,#imageLiteral(resourceName: "banner2") ,#imageLiteral(resourceName: "banner") ,#imageLiteral(resourceName: "banner2") ,#imageLiteral(resourceName: "banner") ,#imageLiteral(resourceName: "banner2") ]

    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

extension ViewController : UICollectionViewDelegate , UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10;
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "check", for: indexPath) as? myCollectionViewCell
        cell?.imgData.image = imgArray[indexPath.row]
        return cell!
    }
}
