//
//  myCollectionViewCell.swift
//  collectionViewMultiScroll
//
//  Created by Hamza Mustafa on 13/10/2020.
//

import UIKit

class myCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgData: UIImageView!
}
